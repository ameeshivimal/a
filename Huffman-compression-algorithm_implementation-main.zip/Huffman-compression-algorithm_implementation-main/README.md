# **Text File Compression using Huffman Algorithm**

It is a text file, script file Compression and Decompression Program which uses Huffman Algorithm for Compression and Decompression

To run this project you need to create an executable file. You can follow the steps given below:
## 1) For compressing:
![image](https://user-images.githubusercontent.com/129995103/230669045-ff993671-8764-4856-854e-7165e5f30e57.png)

## 2) For Decompressing:
![image](https://user-images.githubusercontent.com/129995103/230669131-6bff7aa1-7909-4f4d-ba28-06d97c696631.png)

## Result - 
As a result, while this project is simply an implementation of Huffman coding, it is not as efficient as the current compression algorithm used to compress files.
For instance, inputFile.txt (2.2MB) is compressed to compressedFile.huf (1.1MB) and then decompressed to outputFile.txt (2.2MB).
